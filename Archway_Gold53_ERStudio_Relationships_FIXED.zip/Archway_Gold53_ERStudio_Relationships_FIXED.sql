-- ARCHWAY GOLD 53: ER/STUDIO RELATIONSHIP VISUALIZATION MODEL ONLY
-- SQL SERVER parser compatibility, NOT runnable/deployable Databricks DDL.
-- BUSINESS NATURAL-KEY UNIQUE constraints are diagram scaffolding and DO NOT assert actual uniqueness on SCD2 history.
-- Foreign keys represent proposed logical joins; enforce tenant, as-of dates, and approved source lineage in ETL, not via this script.
-- Select SQL Server (2019+) in ER/Studio SQL File import.
CREATE SCHEMA gold;
GO

-- G-T01 | G01 | Calendar, fiscal dates, breakpoint and reporting-window flags.
CREATE TABLE gold.[dim_date] (
    [DateKey] DATE NOT NULL,
    [CalendarYear] INT NOT NULL,
    [CalendarQuarter] SMALLINT NOT NULL,
    [CalendarMonth] SMALLINT NOT NULL,
    [MonthName] NVARCHAR(500) NOT NULL,
    [FiscalYear] INT NOT NULL,
    [FiscalQuarter] SMALLINT NOT NULL,
    [FiscalMonth] SMALLINT NOT NULL,
    [IsBusinessDay] BIT NOT NULL,
    [IsMonthEnd] BIT NOT NULL,
    [IsQuarterEnd] BIT NOT NULL,
    [IsYearEnd] BIT NOT NULL,
    [IsBreakpointDate] BIT NOT NULL,
    [IsBalanceForward] BIT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT01] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T02 | G03 | Tenant identity, partition and feature switches.
CREATE TABLE gold.[dim_customer] (
    [CustomerID] BIGINT NOT NULL,
    [CustomerName] NVARCHAR(500) NOT NULL,
    [CustomerStatus] NVARCHAR(500) NOT NULL,
    [PartitionNumberF3] SMALLINT NOT NULL,
    [PartitionNumberF2] SMALLINT NOT NULL,
    [LongShortNettingEnabled] BIT NOT NULL,
    [WHConvertedToV2] BIT NOT NULL,
    [AllowDailySecPerf] BIT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT02] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T03 | G02 | Effective-dated fund and reporting-currency master.
CREATE TABLE gold.[dim_fund] (
    [FundID] BIGINT NOT NULL,
    [FundName] NVARCHAR(500) NOT NULL,
    [FundCurrency] NVARCHAR(500) NOT NULL,
    [FundType] NVARCHAR(500) NULL,
    [InceptionDate] DATE NULL,
    [ManagerName] NVARCHAR(500) NULL,
    [CustomerID] BIGINT NOT NULL,
    [IsActive] BIT NOT NULL,
    [WHLockedDate] DATE NULL,
    [ValidFrom] DATE NOT NULL,
    [ValidTo] DATE NULL,
    [IsCurrent] BIT NOT NULL,
    [SourceAuditDate] DATETIME2(6) NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ObservedAtUtc] DATETIME2(6) NOT NULL,
    CONSTRAINT [PK_GT03] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T04 | G03 | Effective-dated security master and financial attributes.
CREATE TABLE gold.[dim_security] (
    [SecurityID] BIGINT NOT NULL,
    [SecurityName] NVARCHAR(500) NOT NULL,
    [Ticker] NVARCHAR(500) NULL,
    [ISIN] NVARCHAR(500) NULL,
    [CUSIP] NVARCHAR(500) NULL,
    [AssetClass] NVARCHAR(500) NULL,
    [SecurityTypeID] BIGINT NULL,
    [SecurityMultiplier] DECIMAL(18,6) NOT NULL,
    [NotionalValue] BIT NOT NULL,
    [IsPrivateEquity] BIT NOT NULL,
    [CashOrCashEquivalent] BIT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [ValidFrom] DATE NOT NULL,
    [ValidTo] DATE NULL,
    [IsCurrent] BIT NOT NULL,
    [SourceAuditDate] DATETIME2(6) NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ObservedAtUtc] DATETIME2(6) NOT NULL,
    CONSTRAINT [PK_GT04] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T05 | G02 | Fund performance breakpoint and prior breakpoint dates.
CREATE TABLE gold.[dim_breakpoint] (
    [BreakpointID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [BreakpointDate] DATE NOT NULL,
    [PriorBreakpointDate] DATE NULL,
    [BreakpointStartDate] DATE NULL,
    [IsRevertible] BIT NOT NULL,
    [IsBalanceForward] BIT NOT NULL,
    [IsInception] BIT NOT NULL,
    [RowNumAsc] INT NOT NULL,
    [RowNumDesc] INT NOT NULL,
    [CustomerID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT05] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T06 | G01 | Conformed currency reference.
CREATE TABLE gold.[dim_currency] (
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    [CurrencyName] NVARCHAR(500) NULL,
    [Region] NVARCHAR(500) NULL,
    [IsBaseCurrency] BIT NOT NULL,
    [DecimalPlaces] SMALLINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT06] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T07 | G02 | Fund chart of accounts for ownership and activity classification.
CREATE TABLE gold.[dim_chart_of_accounts] (
    [COAID] BIGINT NOT NULL,
    [COAAccountCode] NVARCHAR(500) NOT NULL,
    [AccountType] SMALLINT NOT NULL,
    [AccountName] NVARCHAR(500) NULL,
    [FundID] BIGINT NOT NULL,
    [NetOfFeesReporting] BIT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [IsActive] BIT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ValidFrom] DATETIME2(6) NOT NULL,
    [ValidTo] DATETIME2(6) NULL,
    [IsCurrent] BIT NOT NULL,
    [ObservedAtUtc] DATETIME2(6) NOT NULL,
    CONSTRAINT [PK_GT07] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T08 | G01 | Ledger function-code normalization and flags.
CREATE TABLE gold.[dim_glfunction_code] (
    [FunctionCodeID] BIGINT NOT NULL,
    [FunctionCodeName] NVARCHAR(500) NOT NULL,
    [Category] NVARCHAR(500) NOT NULL,
    [DebitCreditDirection] NVARCHAR(500) NOT NULL,
    [IsIncomeCode] BIT NOT NULL,
    [IsAPCode] BIT NOT NULL,
    [IsSettlement] BIT NOT NULL,
    [IsExcludedFromPendingCash] BIT NOT NULL,
    [AccountTypeFilter] NVARCHAR(500) NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT08] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T09 | G01 | Security and portfolio corporate-action reference.
CREATE TABLE gold.[dim_corporate_action] (
    [ActionID] BIGINT NOT NULL,
    [ActionType] NVARCHAR(500) NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [ActionDate] DATE NOT NULL,
    [SpinOffPercentage] DECIMAL(18,6) NULL,
    [IssuePrice] DECIMAL(18,6) NULL,
    [IsPortfolioSpecific] BIT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT09] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T10 | G01 | Normalized transaction direction and special behaviors.
CREATE TABLE gold.[dim_transaction_type] (
    [TransactionTypeKey] INT NOT NULL,
    [TransactionTypeName] NVARCHAR(500) NOT NULL,
    [BuySell] NVARCHAR(500) NULL,
    [IsTransfer] BIT NOT NULL,
    [IsSpinOff] BIT NOT NULL,
    [IsMerger] BIT NOT NULL,
    [IsInKind] BIT NOT NULL,
    [IsGift] BIT NOT NULL,
    [SourceFunctionCode] NVARCHAR(500) NULL,
    [CustomerID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT10] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T11 | G01 | Versioned security price by portfolio and price date.
CREATE TABLE gold.[dim_security_price] (
    [SecurityPriceKey] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [FK_PortfolioID] BIGINT NULL,
    [PriceDate] DATE NOT NULL,
    [SecurityValue] DECIMAL(28,12) NULL,
    [SecurityValue2] DECIMAL(28,12) NULL,
    [SecurityValue3] DECIMAL(28,12) NULL,
    [AnnualizedPayment] DECIMAL(28,12) NULL,
    [ValidFrom] DATE NOT NULL,
    [ValidTo] DATE NULL,
    [IsCurrent] BIT NOT NULL,
    [CustomerID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT11] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T12 | G01 | Security class master.
CREATE TABLE gold.[dim_security_class] (
    [SecurityClassID] BIGINT NOT NULL,
    [SecurityClassName] NVARCHAR(500) NOT NULL,
    [MajorOrMinor] NVARCHAR(500) NOT NULL,
    [SortOrder] INT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceCustomerID] BIGINT NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT12] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T13 | G01 | Security class options and parent class association.
CREATE TABLE gold.[dim_security_class_option] (
    [SecurityClassOptionID] BIGINT NOT NULL,
    [SecurityClassOptionName] NVARCHAR(500) NOT NULL,
    [SecurityClassID] BIGINT NOT NULL,
    [SortOrder] INT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceCustomerID] BIGINT NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT13] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T14 | G01 | Benchmark definitions and synthetic metadata.
CREATE TABLE gold.[dim_benchmark] (
    [BenchmarkRateID] BIGINT NOT NULL,
    [BenchmarkName] NVARCHAR(500) NOT NULL,
    [BenchmarkType] NVARCHAR(500) NULL,
    [IsSynthetic] BIT NOT NULL,
    [SecurityClassID] BIGINT NULL,
    [SortOrder] INT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [IsActive] BIT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT14] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T15 | G01 | Valid long-short and position-direction flag combinations.
CREATE TABLE gold.[junk_long_short_flags] (
    [FlagKey] INT NOT NULL,
    [LongShortMultiplier] SMALLINT NOT NULL,
    [PriorLongShortMultiplier] SMALLINT NOT NULL,
    [DHU] BIT NOT NULL,
    [LongShortNettingEnabled] BIT NOT NULL,
    [IsBalanceForward] BIT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT15] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T16 | G06 | Breakpoint ownership and PAO fan-out from master to feeder profiles.
CREATE TABLE gold.[bridge_nested_profile] (
    [CustomerID] BIGINT NOT NULL,
    [MasterFundID] BIGINT NOT NULL,
    [MasterPortfolioID] BIGINT NOT NULL,
    [ProfileID] BIGINT NOT NULL,
    [BreakPointStart] DATE NOT NULL,
    [BreakPointDate] DATE NOT NULL,
    [Ownership] DECIMAL(28,12) NOT NULL,
    [Allocation] DECIMAL(28,12) NOT NULL,
    [PreAllocationOwnership] DECIMAL(28,12) NOT NULL,
    [PriorPreAllocationOwnership] DECIMAL(28,12) NOT NULL,
    [FeederFundID] BIGINT NOT NULL,
    [FeederPortfolioID] BIGINT NOT NULL,
    [COAID] BIGINT NOT NULL,
    [IsZeroAllocationPlaceholder] BIT NOT NULL,
    [SourceWarehouseNestedProfileID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [OwnershipPathSetID] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT16] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T17 | G05 | Fund/security daily financial kernel results (Fact-3).
CREATE TABLE gold.[fact_daily_security_performance] (
    [SecurityPerformanceID] BIGINT NOT NULL,
    [PartitionNumber] SMALLINT NOT NULL,
    [DHU] BIT NOT NULL,
    [Date] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [PortfolioID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [BreakpointDate] DATETIME2(6) NULL,
    [LocalCurrency] NVARCHAR(500) NOT NULL,
    [LongShortMultiplier] SMALLINT NOT NULL,
    [PriorLongShortMultiplier] SMALLINT NOT NULL,
    [FlagKey] INT NULL,
    [ReportingNumerator] DECIMAL(28,12) NOT NULL,
    [ReportingPriorBasis] DECIMAL(28,12) NOT NULL,
    [ReportingPriorBasisNoUG] DECIMAL(28,12) NOT NULL,
    [ReportingBasisChange] DECIMAL(28,12) NOT NULL,
    [ReportingEndingBasis] DECIMAL(28,12) NOT NULL,
    [ReportingMarketValue] DECIMAL(28,12) NOT NULL,
    [ReportingCashFlow] DECIMAL(28,12) NOT NULL,
    [ReportingCashFlowAdjustment] DECIMAL(28,12) NOT NULL,
    [ReportingIRRCashFlowBasisNoUG] DECIMAL(28,12) NOT NULL,
    [ReportingIRREndingBasis] DECIMAL(28,12) NOT NULL,
    [ReportingIRREndingBasisNoUG] DECIMAL(28,12) NOT NULL,
    [ReportingIRREndingShortAdj] DECIMAL(28,12) NOT NULL,
    [ReportingFXGainLoss] DECIMAL(28,12) NOT NULL,
    [SourceSecurityPerformanceID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [IsOpeningSeed] BIT NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    [InputPolicyID] NVARCHAR(500) NOT NULL,
    [ComponentRole] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT17] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T18 | G06 | Prior-day position and investor opening seed for bounded history.
CREATE TABLE gold.[fact_performance_opening_seed] (
    [OpeningSeedKey] BIGINT NOT NULL,
    [SeedDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [PortfolioID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [ProfileID] BIGINT NULL,
    [FeederFundID] BIGINT NULL,
    [FeederPortfolioID] BIGINT NULL,
    [COAID] BIGINT NULL,
    [ReportingCurrency] NVARCHAR(500) NOT NULL,
    [LongShortMultiplier] SMALLINT NOT NULL,
    [ReportingEndingBasis] DECIMAL(28,12) NOT NULL,
    [ReportingMarketValue] DECIMAL(28,12) NOT NULL,
    [ReportingIRREndingBasis] DECIMAL(28,12) NOT NULL,
    [ReportingIRREndingShortAdj] DECIMAL(28,12) NOT NULL,
    [HistoricalInceptionDate] DATE NULL,
    [SeedLevel] NVARCHAR(500) NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    [InputPolicyID] NVARCHAR(500) NOT NULL,
    [ComponentRole] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT18] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T19 | G06 | Investor-level daily Fact-2 using allocation and PAO scaling.
CREATE TABLE gold.[fact_investor_performance_profile] (
    [DailySecurityPerformanceID] BIGINT NOT NULL,
    [PartitionNumber] SMALLINT NOT NULL,
    [DHU] BIT NOT NULL,
    [Date] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [MasterPortfolioID] BIGINT NOT NULL,
    [MasterFundID] BIGINT NOT NULL,
    [FeederPortfolioID] BIGINT NOT NULL,
    [FeederFundID] BIGINT NOT NULL,
    [COAID] BIGINT NOT NULL,
    [ProfileID] BIGINT NOT NULL,
    [LocalCurrency] NVARCHAR(500) NOT NULL,
    [FeederRow] SMALLINT NOT NULL,
    [LongShortMultiplier] SMALLINT NOT NULL,
    [PriorLongShortMultiplier] SMALLINT NOT NULL,
    [FlagKey] INT NULL,
    [ReportingNumerator] DECIMAL(28,12) NOT NULL,
    [ReportingPriorBasis] DECIMAL(28,12) NOT NULL,
    [ReportingBasisChange] DECIMAL(28,12) NOT NULL,
    [ReportingEndingBasis] DECIMAL(28,12) NOT NULL,
    [ReportingMarketValue] DECIMAL(28,12) NOT NULL,
    [ReportingCashFlow] DECIMAL(28,12) NOT NULL,
    [ReportingCashFlowAdjustment] DECIMAL(28,12) NOT NULL,
    [ReportingIRREndingBasis] DECIMAL(28,12) NOT NULL,
    [ReportingIRREndingShortAdj] DECIMAL(28,12) NOT NULL,
    [ReportingFXGainLoss] DECIMAL(28,12) NOT NULL,
    [SourceDailySecurityPerformanceID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [IsOpeningSeed] BIT NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    [InputPolicyID] NVARCHAR(500) NOT NULL,
    [ComponentRole] NVARCHAR(500) NOT NULL,
    [OwnershipRecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceFact3RecordVersionID] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT19] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T20 | G05 | Effective-dated portfolio and performance attributes.
CREATE TABLE gold.[dim_portfolio] (
    [PortfolioID] BIGINT NOT NULL,
    [PortfolioName] NVARCHAR(500) NOT NULL,
    [StrategyType] NVARCHAR(500) NULL,
    [FundID] BIGINT NOT NULL,
    [PortfolioCash] NVARCHAR(500) NULL,
    [PortfolioDueToDueFrom] NVARCHAR(500) NULL,
    [FK_PendingCashPerfSecurityID] BIGINT NULL,
    [FK_NotionalPerfSecurityID] BIGINT NULL,
    [IsLongShort] BIT NOT NULL,
    [PortfolioCurrency] NVARCHAR(500) NULL,
    [CustomerID] BIGINT NOT NULL,
    [IsCollapsed] BIT NOT NULL,
    [PerformanceStartDate] DATE NULL,
    [ValidFrom] DATE NOT NULL,
    [ValidTo] DATE NULL,
    [IsCurrent] BIT NOT NULL,
    [SourceAuditDate] DATETIME2(6) NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ObservedAtUtc] DATETIME2(6) NOT NULL,
    CONSTRAINT [PK_GT20] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T21 | G03 | Profile/investor master for reporting and ownership.
CREATE TABLE gold.[dim_investor_profile] (
    [ProfileID] BIGINT NOT NULL,
    [ProfileName] NVARCHAR(500) NOT NULL,
    [InvestorType] NVARCHAR(500) NULL,
    [FeederFundID] BIGINT NULL,
    [FeederPortfolioID] BIGINT NULL,
    [CustomerID] BIGINT NOT NULL,
    [IsActive] BIT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ValidFrom] DATETIME2(6) NOT NULL,
    [ValidTo] DATETIME2(6) NULL,
    [IsCurrent] BIT NOT NULL,
    [ObservedAtUtc] DATETIME2(6) NOT NULL,
    CONSTRAINT [PK_GT21] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T22 | G06 | Six grouping contexts and class-option reporting metadata.
CREATE TABLE gold.[dim_page_grouping] (
    [PageGroupingID] BIGINT NOT NULL,
    [PageGroupingName] NVARCHAR(500) NOT NULL,
    [GroupingType] NVARCHAR(500) NOT NULL,
    [SourceObjectID] BIGINT NOT NULL,
    [FeederFundID] BIGINT NULL,
    [FeederPortfolioID] BIGINT NULL,
    [GlobalClassOptionID] BIGINT NULL,
    [ProfileClassOptionID] BIGINT NULL,
    [ClassID] BIGINT NULL,
    [ClassOptionID] BIGINT NULL,
    [MasterFeederFlag] NVARCHAR(500) NOT NULL,
    [LookThroughFlag] BIT NOT NULL,
    [InceptionDate] DATE NULL,
    [CollapseFlag] BIT NOT NULL,
    [SuppressNonTotalPerformance] BIT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [IsActive] BIT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [NodeType] NVARCHAR(500) NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [MembershipSetID] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT22] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T23 | G01 | Valid customer major/minor class combinations.
CREATE TABLE gold.[bridge_report_security_class_pair] (
    [ReportSecurityClassPairKey] BIGINT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [MajorSecurityClassID] BIGINT NOT NULL,
    [MinorSecurityClassID] BIGINT NOT NULL,
    [PairName] NVARCHAR(500) NULL,
    [IsDefault] BIT NOT NULL,
    [IsActive] BIT NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT23] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T24 | G07 | Materialized report parameter context.
CREATE TABLE gold.[dim_report_context] (
    [ReportContextKey] BIGINT NOT NULL,
    [ContextCode] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [ActiveFundID] BIGINT NOT NULL,
    [GroupingType] NVARCHAR(500) NOT NULL,
    [PageGroupingID] BIGINT NOT NULL,
    [SourceObjectID] BIGINT NOT NULL,
    [MasterFeederFlag] NVARCHAR(500) NOT NULL,
    [LookThroughFlag] BIT NOT NULL,
    [ReportStartDate] DATE NOT NULL,
    [ReportEndDate] DATE NOT NULL,
    [IsRolling] BIT NOT NULL,
    [IsCalendarYear] BIT NOT NULL,
    [CalcMethod] NVARCHAR(500) NOT NULL,
    [AnnualizeFlag] BIT NOT NULL,
    [DeAnnualizeFlag] BIT NOT NULL,
    [FeeType] NVARCHAR(500) NOT NULL,
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    [MajorSecurityClassID] BIGINT NOT NULL,
    [MinorSecurityClassID] BIGINT NOT NULL,
    [IsActive] BIT NOT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [BeginningEndingBasis] BIT NULL,
    [ContinuousBasis] BIT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CalculationContextID] NVARCHAR(500) NOT NULL,
    [SelectionSetID] NVARCHAR(500) NOT NULL,
    [GroupingDefinitionID] NVARCHAR(500) NOT NULL,
    [PolicySetID] NVARCHAR(500) NOT NULL,
    [CanonicalContextJSON] NVARCHAR(500) NOT NULL,
    [ContextFingerprint] NVARCHAR(500) NOT NULL,
    [ResolvedFeatureSetID] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT24] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T25 | G07 | Selected and standard period window definitions and coverage.
CREATE TABLE gold.[dim_report_time_period] (
    [ReportTimePeriodID] BIGINT NOT NULL,
    [PeriodKey] NVARCHAR(500) NOT NULL,
    [PeriodOrdinal] SMALLINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [ReportStartDate] DATE NOT NULL,
    [ReportEndDate] DATE NOT NULL,
    [PeriodStartDate] DATE NOT NULL,
    [PeriodEndDate] DATE NOT NULL,
    [PeriodDays] INT NOT NULL,
    [IsRolling] BIT NOT NULL,
    [IsCalendarYear] BIT NOT NULL,
    [IsInceptionPeriod] BIT NOT NULL,
    [InceptionDate] DATE NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [DataCoverageStartDate] DATE NULL,
    [IsCompleteWindow] BIT NOT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [CoverageStatus] NVARCHAR(500) NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ResolvedWindowID] NVARCHAR(500) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [OpeningValueDate] DATE NULL,
    [HistoryEndExclusive] DATE NOT NULL,
    CONSTRAINT [PK_GT25] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T26 | G03 | Effective-dated major/minor security classifications.
CREATE TABLE gold.[bridge_security_classification] (
    [CustomerID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [MajorSecurityClassID] BIGINT NOT NULL,
    [MajorSecurityClassOptionID] BIGINT NOT NULL,
    [MinorSecurityClassID] BIGINT NOT NULL,
    [MinorSecurityClassOptionID] BIGINT NOT NULL,
    [ValidFrom] DATE NOT NULL,
    [ValidTo] DATE NULL,
    [IsCurrent] BIT NOT NULL,
    [SourceMajorClassificationID] BIGINT NULL,
    [SourceMinorClassificationID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT26] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T27 | G07 | Effective-dated hierarchy of benchmark assignments.
CREATE TABLE gold.[bridge_benchmark_assignment] (
    [BenchmarkAssignmentID] BIGINT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [PageGroupingID] BIGINT NOT NULL,
    [BenchmarkRateID] BIGINT NOT NULL,
    [BenchmarkLevel] NVARCHAR(500) NOT NULL,
    [SecurityClassOptionMajorID] BIGINT NULL,
    [SecurityClassOptionMinorID] BIGINT NULL,
    [SecurityID] BIGINT NULL,
    [EffectiveDate] DATE NOT NULL,
    [ExpiryDate] DATE NULL,
    [IsCurrent] BIT NOT NULL,
    [SourceTable] NVARCHAR(500) NULL,
    [SourceAssignmentID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT27] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T28 | G04 | Daily directional FX rates.
CREATE TABLE gold.[fact_exchange_rate_daily] (
    [ExchangeRateDailyKey] BIGINT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [RateDate] DATE NOT NULL,
    [FromCurrency] NVARCHAR(500) NOT NULL,
    [ToCurrency] NVARCHAR(500) NOT NULL,
    [ExchangeRate] DECIMAL(28,12) NOT NULL,
    [IsEstimated] BIT NOT NULL,
    [SourceExchangeRateID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT28] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T29 | G05 | Atomic position, cash-flow, income and basis calculation inputs.
CREATE TABLE gold.[fact_daily_returns_base] (
    [DailyReturnsBaseID] BIGINT NOT NULL,
    [AuditUser] NVARCHAR(500) NULL,
    [AuditDate] DATETIME2(6) NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [PortfolioID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [Date] DATETIME2(6) NOT NULL,
    [Numerator] DECIMAL(30,14) NULL,
    [Denominator] DECIMAL(30,14) NULL,
    [whIncome] DECIMAL(30,14) NULL,
    [Amm] DECIMAL(30,14) NULL,
    [Book] DECIMAL(30,14) NULL,
    [Quantity] DECIMAL(30,14) NULL,
    [BuyCost] DECIMAL(30,14) NULL,
    [BuyQuantity] DECIMAL(30,14) NULL,
    [PriorBook] DECIMAL(30,14) NULL,
    [PriorQuantity] DECIMAL(30,14) NULL,
    [SellCost] DECIMAL(30,14) NULL,
    [SellQuantity] DECIMAL(30,14) NULL,
    [TransferQuantity] DECIMAL(30,14) NULL,
    [InKindUG] DECIMAL(30,14) NULL,
    [TransferValue] DECIMAL(30,14) NULL,
    [CallBasis] DECIMAL(30,14) NULL,
    [CallIncome] DECIMAL(30,14) NULL,
    [DistributionBasis] DECIMAL(30,14) NULL,
    [DistributionIncome] DECIMAL(30,14) NULL,
    [TransferBasisOut] DECIMAL(30,14) NULL,
    [TransferBasisIn] DECIMAL(30,14) NULL,
    [ManualBasisIn] DECIMAL(30,14) NULL,
    [ManualBasisOut] DECIMAL(30,14) NULL,
    [ManualBasisIncome] DECIMAL(30,14) NULL,
    [DayPurchaseIncome] DECIMAL(30,14) NULL,
    [DaySaleIncome] DECIMAL(30,14) NULL,
    [DayPositionIncome] DECIMAL(30,14) NULL,
    [InKindUGIn] DECIMAL(30,14) NULL,
    [InKindUGOut] DECIMAL(30,14) NULL,
    [SourceBaseID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    [InputPolicyID] NVARCHAR(500) NOT NULL,
    [ComponentRole] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT29] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T30 | G05 | Realized gains, manual basis permutations and tax lots.
CREATE TABLE gold.[fact_realized_gains_tax_lot] (
    [RealizedGainsTaxLotID] BIGINT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [PortfolioID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [Date] DATE NOT NULL,
    [UniqueIdentifyingID] NVARCHAR(500) NOT NULL,
    [LotSuffix] NVARCHAR(500) NOT NULL,
    [OpenGLID] BIGINT NULL,
    [CloseGLID] BIGINT NULL,
    [OpenDate] DATE NULL,
    [CloseDate] DATE NULL,
    [PurchasePrice] DECIMAL(30,14) NULL,
    [SalePrice] DECIMAL(30,14) NULL,
    [Quantity] DECIMAL(30,14) NULL,
    [ReportingOpeningCost] DECIMAL(30,14) NULL,
    [ReportingClosingCost] DECIMAL(30,14) NULL,
    [ReportingPriorOpenMarketValue] DECIMAL(30,14) NULL,
    [ReportingCurrentOpenMarketValue] DECIMAL(30,14) NULL,
    [LocalManualBasisIn_TranOpen_GLClose] DECIMAL(30,14) NULL,
    [LocalManualBasisOut_TranOpen_GLClose] DECIMAL(30,14) NULL,
    [LocalManualBasisIn_TranClose_GLOpen] DECIMAL(30,14) NULL,
    [LocalManualBasisOut_TranClose_GLOpen] DECIMAL(30,14) NULL,
    [LocalManualBasisIn_GLClose_TranOpen] DECIMAL(30,14) NULL,
    [LocalManualBasisOut_GLClose_TranOpen] DECIMAL(30,14) NULL,
    [LocalManualBasisIn_GLOpen_TranClose] DECIMAL(30,14) NULL,
    [LocalManualBasisOut_GLOpen_TranClose] DECIMAL(30,14) NULL,
    [ReportingManualBasisIn_TranOpen_GLClose] DECIMAL(30,14) NULL,
    [ReportingManualBasisOut_TranOpen_GLClose] DECIMAL(30,14) NULL,
    [ReportingManualBasisIn_TranClose_GLOpen] DECIMAL(30,14) NULL,
    [ReportingManualBasisOut_TranClose_GLOpen] DECIMAL(30,14) NULL,
    [ReportingManualBasisIn_GLClose_TranOpen] DECIMAL(30,14) NULL,
    [ReportingManualBasisOut_GLClose_TranOpen] DECIMAL(30,14) NULL,
    [ReportingManualBasisIn_GLOpen_TranClose] DECIMAL(30,14) NULL,
    [ReportingManualBasisOut_GLOpen_TranClose] DECIMAL(30,14) NULL,
    [ReportingSpinoff] DECIMAL(30,14) NULL,
    [ReportingMerger] DECIMAL(30,14) NULL,
    [ReportingIRRBasisCashFlow] DECIMAL(30,14) NULL,
    [ReportingIRREndingBasis] DECIMAL(30,14) NULL,
    [ReportingIRREndingShortAdj] DECIMAL(30,14) NULL,
    [LongShortMultiplier] SMALLINT NOT NULL,
    [LocalCurrency] NVARCHAR(500) NULL,
    [ReportingCurrency] NVARCHAR(500) NULL,
    [SourceCategory] NVARCHAR(500) NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceCompletenessCode] NVARCHAR(500) NOT NULL,
    [IsComplete] BIT NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT30] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T31 | G04 | Normalized GL postings, converted amounts and flags.
CREATE TABLE gold.[fact_general_ledger_activity] (
    [GeneralLedgerActivityID] BIGINT NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [PortfolioID] BIGINT NULL,
    [SecurityID] BIGINT NULL,
    [COAID] BIGINT NULL,
    [FunctionCodeID] BIGINT NULL,
    [GLID] BIGINT NOT NULL,
    [GLRowID] BIGINT NOT NULL,
    [GLDate] DATE NOT NULL,
    [GLAccountCode] NVARCHAR(500) NULL,
    [Debit] DECIMAL(30,14) NOT NULL,
    [Credit] DECIMAL(30,14) NOT NULL,
    [LocalAmount] DECIMAL(30,14) NULL,
    [GLCurrency] NVARCHAR(500) NULL,
    [GLBaseCurrency] NVARCHAR(500) NULL,
    [GLExchangeRate] DECIMAL(30,14) NULL,
    [MultiCurrencyMultiplier] DECIMAL(30,14) NULL,
    [ReportingAmount] DECIMAL(30,14) NULL,
    [IsIncome] BIT NOT NULL,
    [IsAccrual] BIT NOT NULL,
    [IsAP] BIT NOT NULL,
    [IsBasisAdjustment] BIT NOT NULL,
    [IsSettlement] BIT NOT NULL,
    [AuditUser] NVARCHAR(500) NULL,
    [AuditDate] DATETIME2(6) NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT31] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T32 | G06 | Allocated investor cash flow and GL/transaction activity.
CREATE TABLE gold.[fact_investor_activity] (
    [InvestorActivityKey] BIGINT NOT NULL,
    [ActivityDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [PortfolioID] BIGINT NULL,
    [ProfileID] BIGINT NULL,
    [SecurityID] BIGINT NULL,
    [COAID] BIGINT NULL,
    [ActivityType] NVARCHAR(500) NOT NULL,
    [LocalCurrency] NVARCHAR(500) NULL,
    [ReportingCurrency] NVARCHAR(500) NOT NULL,
    [LocalAmount] DECIMAL(28,12) NOT NULL,
    [ReportingAmount] DECIMAL(28,12) NOT NULL,
    [Quantity] DECIMAL(28,12) NULL,
    [SourceTransactionID] BIGINT NULL,
    [SourceGLID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT32] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T33 | G07 | As-of security classification and display details.
CREATE TABLE gold.[snap_security_classification] (
    [SecurityClassificationSnapshotID] BIGINT NOT NULL,
    [SnapshotDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [MajorSecurityClassID] BIGINT NOT NULL,
    [MajorSecurityClassOptionID] BIGINT NOT NULL,
    [MajorSecurityClassOptionName] NVARCHAR(500) NOT NULL,
    [MajorSortOrder] INT NOT NULL,
    [MinorSecurityClassID] BIGINT NOT NULL,
    [MinorSecurityClassOptionID] BIGINT NOT NULL,
    [MinorSecurityClassOptionName] NVARCHAR(500) NOT NULL,
    [MinorSortOrder] INT NOT NULL,
    [CashOrCashEquivalent] BIT NOT NULL,
    [IsOtherAsset] BIT NOT NULL,
    [SourceMajorEffectiveDate] DATE NULL,
    [SourceMinorEffectiveDate] DATE NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT33] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T34 | G08 | As-of calculation and report display inception dates.
CREATE TABLE gold.[snap_inception_dates] (
    [InceptionDateSnapshotID] BIGINT NOT NULL,
    [SnapshotDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [GroupingType] NVARCHAR(500) NOT NULL,
    [PageGroupingID] BIGINT NOT NULL,
    [MasterFeederFlag] NVARCHAR(500) NOT NULL,
    [LookThroughFlag] BIT NOT NULL,
    [RollupLevel] NVARCHAR(500) NOT NULL,
    [SecurityClassOptionMajorID] BIGINT NOT NULL,
    [SecurityClassOptionMinorID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [InceptionDate] DATE NOT NULL,
    [InceptionDateDisplay] DATE NOT NULL,
    [ContinuousBasisFlag] BIT NOT NULL,
    [SourceRowCount] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [MajorSecurityClassID] BIGINT NULL,
    [MinorSecurityClassID] BIGINT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [PublicationRunID] NVARCHAR(500) NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT34] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T35 | G08 | Pre-aggregated TW/XIRR inputs, eligibility and period coverage.
CREATE TABLE gold.[snap_period_performance] (
    [PeriodPerformanceSnapshotID] BIGINT NOT NULL,
    [SnapshotDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [GroupingType] NVARCHAR(500) NOT NULL,
    [PageGroupingID] BIGINT NOT NULL,
    [MasterFeederFlag] NVARCHAR(500) NOT NULL,
    [LookThroughFlag] BIT NOT NULL,
    [RollupLevel] NVARCHAR(500) NOT NULL,
    [SecurityClassOptionMajorID] BIGINT NOT NULL,
    [SecurityClassOptionMinorID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [PeriodKey] NVARCHAR(500) NOT NULL,
    [PeriodStartDate] DATE NOT NULL,
    [PeriodEndDate] DATE NOT NULL,
    [PeriodDays] INT NOT NULL,
    [FeeType] NVARCHAR(500) NOT NULL,
    [DetailType] NVARCHAR(500) NOT NULL,
    [SumReportingNumerator] DECIMAL(38,12) NOT NULL,
    [SumReportingPriorBasis] DECIMAL(38,12) NOT NULL,
    [SumReportingBasisChange] DECIMAL(38,12) NOT NULL,
    [SumReportingCashFlowAdj] DECIMAL(38,12) NOT NULL,
    [SumReportingEndingBasis] DECIMAL(38,12) NOT NULL,
    [SumReportingMarketValue] DECIMAL(38,12) NOT NULL,
    [SumReportingCashFlow] DECIMAL(38,12) NOT NULL,
    [SumReportingIRREndingBasis] DECIMAL(38,12) NOT NULL,
    [SumReportingIRREndingShortAdj] DECIMAL(38,12) NOT NULL,
    [SumPriorBasisXLSM] DECIMAL(38,12) NOT NULL,
    [SumBasisChangeXNeg] DECIMAL(38,12) NOT NULL,
    [OpeningIRRMarketValue] DECIMAL(38,12) NOT NULL,
    [ClosingIRRMarketValue] DECIMAL(38,12) NOT NULL,
    [TWRReturnRaw] FLOAT NULL,
    [XIRRReturnRaw] FLOAT NULL,
    [XIRRShortReturnMultiplier] SMALLINT NOT NULL,
    [InPositionFlag] BIT NOT NULL,
    [InPositionEnd] BIT NOT NULL,
    [DirectionChanged] BIT NOT NULL,
    [LongShortNettingEnabled] BIT NOT NULL,
    [IsBalanceForward] BIT NOT NULL,
    [DailyRowCount] INT NOT NULL,
    [CashFlowEventCount] INT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [MajorSecurityClassID] BIGINT NULL,
    [MinorSecurityClassID] BIGINT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [IsRolling] BIT NULL,
    [CoverageStatus] NVARCHAR(500) NULL,
    [InceptionDateUsed] DATE NULL,
    [IsCompleteWindow] BIT NOT NULL,
    [PublicationRunID] NVARCHAR(500) NULL,
    [BeginningEndingBasis] BIT NULL,
    [ContinuousBasis] BIT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT35] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T36 | G08 | Period-aligned benchmark return calculations.
CREATE TABLE gold.[snap_benchmark_returns_by_period] (
    [BenchmarkReturnSnapshotID] BIGINT NOT NULL,
    [SnapshotDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [GroupingType] NVARCHAR(500) NOT NULL,
    [PageGroupingID] BIGINT NOT NULL,
    [MasterFeederFlag] NVARCHAR(500) NOT NULL,
    [LookThroughFlag] BIT NOT NULL,
    [RollupLevel] NVARCHAR(500) NOT NULL,
    [SecurityClassOptionMajorID] BIGINT NOT NULL,
    [SecurityClassOptionMinorID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [PeriodKey] NVARCHAR(500) NOT NULL,
    [PeriodStartDate] DATE NOT NULL,
    [PeriodEndDate] DATE NOT NULL,
    [PeriodDays] INT NOT NULL,
    [BenchmarkRateID] BIGINT NOT NULL,
    [BenchmarkReturnRaw] DECIMAL(28,12) NULL,
    [BenchmarkReturnValue] DECIMAL(28,12) NULL,
    [BenchmarkReturnAnnualised] DECIMAL(28,12) NULL,
    [IsCompleteWindow] BIT NOT NULL,
    [MajorSecurityClassID] BIGINT NULL,
    [MinorSecurityClassID] BIGINT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [IsRolling] BIT NULL,
    [PublicationRunID] NVARCHAR(500) NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT36] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T37 | G08 | Period-aware financial return and benchmark snapshot.
CREATE TABLE gold.[snap_returns_by_period] (
    [ReturnSnapshotID] BIGINT NOT NULL,
    [PeriodPerformanceSnapshotID] BIGINT NOT NULL,
    [SnapshotDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [GroupingType] NVARCHAR(500) NOT NULL,
    [PageGroupingID] BIGINT NOT NULL,
    [MasterFeederFlag] NVARCHAR(500) NOT NULL,
    [LookThroughFlag] BIT NOT NULL,
    [RollupLevel] NVARCHAR(500) NOT NULL,
    [SecurityClassOptionMajorID] BIGINT NOT NULL,
    [SecurityClassOptionMinorID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [PeriodKey] NVARCHAR(500) NOT NULL,
    [PeriodStartDate] DATE NOT NULL,
    [PeriodEndDate] DATE NOT NULL,
    [PeriodDays] INT NOT NULL,
    [CalcMethod] NVARCHAR(500) NOT NULL,
    [FeeType] NVARCHAR(500) NOT NULL,
    [DetailType] NVARCHAR(500) NOT NULL,
    [ReturnValue] FLOAT NULL,
    [ReturnValueAnnualised] FLOAT NULL,
    [ReturnValueCumulative] FLOAT NULL,
    [IsInvalid] BIT NOT NULL,
    [IsInPosition] BIT NOT NULL,
    [InPositionEnd] BIT NOT NULL,
    [DirectionChanged] BIT NOT NULL,
    [LongShortNettingEnabled] BIT NOT NULL,
    [IsBalanceForward] BIT NOT NULL,
    [BenchmarkRateID] BIGINT NULL,
    [BenchmarkReturnValue] FLOAT NULL,
    [BenchmarkReturnValueAnnualised] FLOAT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [IsCompleteWindow] BIT NOT NULL,
    [MajorSecurityClassID] BIGINT NULL,
    [MinorSecurityClassID] BIGINT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [IsRolling] BIT NULL,
    [CoverageStatus] NVARCHAR(500) NULL,
    [InceptionDateUsed] DATE NULL,
    [PublicationRunID] NVARCHAR(500) NULL,
    [BeginningEndingBasis] BIT NULL,
    [ContinuousBasis] BIT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT37] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T38 | G08 | Beginning/ending MV and basis snapshot.
CREATE TABLE gold.[snap_market_value_latest] (
    [MarketValueSnapshotID] BIGINT NOT NULL,
    [SnapshotDate] DATE NOT NULL,
    [BeginDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [GroupingType] NVARCHAR(500) NOT NULL,
    [PageGroupingID] BIGINT NOT NULL,
    [MasterFeederFlag] NVARCHAR(500) NOT NULL,
    [LookThroughFlag] BIT NOT NULL,
    [RollupLevel] NVARCHAR(500) NOT NULL,
    [SecurityClassOptionMajorID] BIGINT NOT NULL,
    [SecurityClassOptionMinorID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [FeeType] NVARCHAR(500) NOT NULL,
    [DetailType] NVARCHAR(500) NOT NULL,
    [BeginningMarketValue] DECIMAL(38,12) NULL,
    [EndingMarketValue] DECIMAL(38,12) NULL,
    [BeginningBasis] DECIMAL(38,12) NULL,
    [EndingBasis] DECIMAL(38,12) NULL,
    [InPositionBeginning] BIT NOT NULL,
    [InPositionEnd] BIT NOT NULL,
    [UsedEstimatedPrice] BIT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [MajorSecurityClassID] BIGINT NULL,
    [MinorSecurityClassID] BIGINT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [BeginningValueStatus] NVARCHAR(500) NULL,
    [PublicationRunID] NVARCHAR(500) NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    [HasValuation] BIT NOT NULL,
    [HasActivity] BIT NOT NULL,
    [HasReturnObservation] BIT NOT NULL,
    [ReturnEligibilityStatus] NVARCHAR(500) NOT NULL,
    [PresenceReason] NVARCHAR(500) NOT NULL,
    [ValuationPolicyID] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT38] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T39 | G08 | Published BI period returns, copied from accepted snapshot.
CREATE TABLE gold.[fact_returns_by_period] (
    [ReturnsByPeriodID] BIGINT NOT NULL,
    [SnapshotDate] DATE NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [FundID] BIGINT NOT NULL,
    [GroupingType] NVARCHAR(500) NOT NULL,
    [PageGroupingID] BIGINT NOT NULL,
    [MasterFeederFlag] NVARCHAR(500) NOT NULL,
    [LookThroughFlag] BIT NOT NULL,
    [RollupLevel] NVARCHAR(500) NOT NULL,
    [SecurityClassOptionMajorID] BIGINT NOT NULL,
    [SecurityClassOptionMinorID] BIGINT NOT NULL,
    [SecurityID] BIGINT NOT NULL,
    [PeriodKey] NVARCHAR(500) NOT NULL,
    [PeriodStartDate] DATE NOT NULL,
    [PeriodEndDate] DATE NOT NULL,
    [PeriodDays] INT NOT NULL,
    [CalcMethod] NVARCHAR(500) NOT NULL,
    [FeeType] NVARCHAR(500) NOT NULL,
    [DetailType] NVARCHAR(500) NOT NULL,
    [ReturnValue] FLOAT NULL,
    [ReturnValueAnnualised] FLOAT NULL,
    [ReturnValueCumulative] FLOAT NULL,
    [IsInvalid] BIT NOT NULL,
    [IsInPosition] BIT NOT NULL,
    [DirectionChanged] BIT NOT NULL,
    [LongShortNettingEnabled] BIT NOT NULL,
    [IsBalanceForward] BIT NOT NULL,
    [BenchmarkRateID] BIGINT NULL,
    [BenchmarkReturnValue] FLOAT NULL,
    [BenchmarkReturnValueAnnualised] FLOAT NULL,
    [SourceSnapReturnID] BIGINT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [IsCompleteWindow] BIT NOT NULL,
    [MajorSecurityClassID] BIGINT NULL,
    [MinorSecurityClassID] BIGINT NULL,
    [ModelVersion] SMALLINT NOT NULL,
    [IsRolling] BIT NULL,
    [CoverageStatus] NVARCHAR(500) NULL,
    [InceptionDateUsed] DATE NULL,
    [PublicationRunID] NVARCHAR(500) NULL,
    [BeginningEndingBasis] BIT NULL,
    [ContinuousBasis] BIT NULL,
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT39] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T40 | G05 | Position valuation independent of return eligibility.
CREATE TABLE gold.[fact_position_valuation_daily] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [MonetaryObjectID] NVARCHAR(500) NOT NULL,
    [ObjectType] NVARCHAR(500) NOT NULL,
    [FundID] BIGINT NULL,
    [PortfolioID] BIGINT NULL,
    [SecurityID] BIGINT NULL,
    [COAID] BIGINT NULL,
    [ValuationDate] DATE NOT NULL,
    [LocalCurrencyCode] NVARCHAR(500) NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NULL,
    [Quantity] DECIMAL(38,13) NULL,
    [UnitPrice] FLOAT NULL,
    [SecurityMultiplier] FLOAT NULL,
    [SourcePriceID] BIGINT NULL,
    [SecurityPriceVersionID] NVARCHAR(500) NULL,
    [PriceObservationDate] DATE NULL,
    [FXRateRecordVersionID] NVARCHAR(500) NULL,
    [LocalMarketValue] DECIMAL(38,14) NULL,
    [ReportingMarketValue] DECIMAL(38,14) NULL,
    [OpenAccruedAmount] DECIMAL(38,14) NULL,
    [ClosedAccruedAmount] DECIMAL(38,14) NULL,
    [ReportingBasis] DECIMAL(38,14) NULL,
    [ValuationPolicyID] NVARCHAR(500) NULL,
    [PresenceStatus] NVARCHAR(500) NULL,
    [PriceStatus] NVARCHAR(500) NULL,
    [ReturnEligibilityStatus] NVARCHAR(500) NULL,
    [OwnershipInputSetID] NVARCHAR(500) NULL,
    CONSTRAINT [PK_GT40] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T41 | G01 | Atomic signed transaction economic event fact.
CREATE TABLE gold.[fact_transaction] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [TransactionID] BIGINT NOT NULL,
    [GLID] BIGINT NULL,
    [CashGLID] BIGINT NULL,
    [FundID] BIGINT NULL,
    [PortfolioID] BIGINT NULL,
    [SecurityID] BIGINT NULL,
    [TradeDate] DATE NULL,
    [SettlementDate] DATE NULL,
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    [TransactionTypeKey] BIGINT NULL,
    [SourceTransactionType] NVARCHAR(500) NULL,
    [BuySell] NVARCHAR(500) NULL,
    [Quantity] DECIMAL(38,13) NULL,
    [UnitPrice] DECIMAL(38,13) NULL,
    [TotalCost] DECIMAL(38,13) NULL,
    [AccruedInterest] DECIMAL(38,13) NULL,
    [CommissionComponents] ARRAY<STRUCT<COMPONENTCODE:STRING,AMOUNT:DECIMAL(38,13)>> NULL,
    [TaxBasis] DECIMAL(38,13) NULL,
    [EconomicEventKey] NVARCHAR(500) NOT NULL,
    [PerformanceRecognitionRole] NVARCHAR(500) NULL,
    [SourceAuditDate] DATETIME2(6) NULL,
    CONSTRAINT [PK_GT41] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T42 | G07 | Reusable raw benchmark observations.
CREATE TABLE gold.[fact_benchmark_observation] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [BenchmarkRateID] BIGINT NULL,
    [SourceObservationID] BIGINT NULL,
    [ObservationDate] DATE NULL,
    [ObservationKind] NVARCHAR(500) NOT NULL,
    [ObservedValue] FLOAT NULL,
    [ObservationStartDate] DATE NULL,
    [ObservationEndDate] DATE NULL,
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    [ReturnBasis] NVARCHAR(500) NULL,
    [SeriesVersion] NVARCHAR(500) NOT NULL,
    [SyntheticInputSetID] NVARCHAR(500) NULL,
    [QualityStatus] NVARCHAR(500) NULL,
    CONSTRAINT [PK_GT42] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T43 | G01 | Versioned allocation model and target classification.
CREATE TABLE gold.[dim_allocation_model] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [AllocationModelID] BIGINT NULL,
    [ModelName] NVARCHAR(500) NULL,
    [ModelCode] NVARCHAR(500) NULL,
    [SecurityTypeModel] BIT NULL,
    [SecurityClassModel] BIT NULL,
    [SecurityClassID] BIGINT NULL,
    [ValidFrom] DATETIME2(6) NULL,
    [ValidTo] DATETIME2(6) NULL,
    [ObservedAtUtc] DATETIME2(6) NULL,
    [HistoryStatus] NVARCHAR(500) NULL,
    CONSTRAINT [PK_GT43] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T44 | G07 | Effective allocation weights and tolerances.
CREATE TABLE gold.[fact_allocation_target] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [AllocationModelID] BIGINT NULL,
    [AllocationModelVersionID] NVARCHAR(500) NOT NULL,
    [BindingSourceTable] NVARCHAR(500) NOT NULL,
    [BindingSourceID] BIGINT NOT NULL,
    [SubjectType] NVARCHAR(500) NOT NULL,
    [FundID] BIGINT NULL,
    [PortfolioID] BIGINT NULL,
    [BucketType] NVARCHAR(500) NOT NULL,
    [BucketNativeID] BIGINT NULL,
    [SecurityClassOptionID] BIGINT NULL,
    [TargetWeightRaw] DECIMAL(38,14) NULL,
    [TargetWeight] DECIMAL(38,14) NULL,
    [TolerancePlus] DECIMAL(38,14) NULL,
    [ToleranceMinus] DECIMAL(38,14) NULL,
    [TolerancePercentage] BIT NULL,
    [EffectiveFrom] DATE NOT NULL,
    [EffectiveToExclusive] DATE NULL,
    CONSTRAINT [PK_GT44] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T45 | G04 | Commitment and subscription contract identities.
CREATE TABLE gold.[dim_investment_contract] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [InvestmentContractID] NVARCHAR(500) NOT NULL,
    [ContractType] NVARCHAR(500) NOT NULL,
    [SourceContractID] BIGINT NOT NULL,
    [PositionBusinessKey] NVARCHAR(500) NOT NULL,
    [FundID] BIGINT NULL,
    [PortfolioID] BIGINT NULL,
    [SecurityID] BIGINT NULL,
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    [ContractDate] DATE NULL,
    [FundingDate] DATE NULL,
    [ExpirationDate] DATE NULL,
    [OriginalAmount] DECIMAL(38,14) NULL,
    [GLID] BIGINT NULL,
    [SourcePolicyComponents] ARRAY<STRUCT<COMPONENTCODE:STRING,UPDATESMV:BOOLEAN,UPDATESCOMMITMENT:BOOLEAN,RECALLABLEPERCENT:DECIMAL(38,14)>> NULL,
    [ValidFrom] DATETIME2(6) NULL,
    [ValidTo] DATETIME2(6) NULL,
    [HistoryStatus] NVARCHAR(500) NULL,
    CONSTRAINT [PK_GT45] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T46 | G05 | Capital call/distribution component events and recognition policy.
CREATE TABLE gold.[fact_private_capital_event_component] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [InvestmentContractID] NVARCHAR(500) NOT NULL,
    [InvestmentContractVersionID] NVARCHAR(500) NOT NULL,
    [SourceEventTable] NVARCHAR(500) NOT NULL,
    [SourceEventID] BIGINT NOT NULL,
    [ComponentCode] NVARCHAR(500) NOT NULL,
    [EventDate] DATE NULL,
    [FundingDate] DATE NULL,
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    [ComponentAmount] DECIMAL(38,14) NULL,
    [EconomicCashFlowSign] SMALLINT NULL,
    [UpdatesMarketValue] BIT NULL,
    [UpdatesRemainingCommitment] BIT NULL,
    [RecallablePercentRaw] DECIMAL(38,14) NULL,
    [SourceCOAID] BIGINT NULL,
    [GLID] BIGINT NULL,
    [EconomicEventKey] NVARCHAR(500) NOT NULL,
    [RecognitionPolicyID] NVARCHAR(500) NULL,
    CONSTRAINT [PK_GT46] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T47 | G09 | As-of private capital position/multiple components.
CREATE TABLE gold.[snap_private_capital_position] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [InvestmentContractID] NVARCHAR(500) NOT NULL,
    [InvestmentContractVersionID] NVARCHAR(500) NOT NULL,
    [AsOfDate] DATE NOT NULL,
    [ReportingCurrencyCode] NVARCHAR(500) NULL,
    [CapitalPolicyID] NVARCHAR(500) NOT NULL,
    [CommitmentAmount] DECIMAL(38,14) NULL,
    [CalledAmount] DECIMAL(38,14) NULL,
    [FeesAmount] DECIMAL(38,14) NULL,
    [DistributedCapital] DECIMAL(38,14) NULL,
    [DistributedIncome] DECIMAL(38,14) NULL,
    [RecallableAmount] DECIMAL(38,14) NULL,
    [RemainingCommitment] DECIMAL(38,14) NULL,
    [AllocatedNAV] DECIMAL(38,14) NULL,
    [PaidInDenominator] DECIMAL(38,14) NULL,
    [DPI] FLOAT NULL,
    [RVPI] FLOAT NULL,
    [TVPI] FLOAT NULL,
    [NAVAllocationStatus] NVARCHAR(500) NULL,
    [CoverageStatus] NVARCHAR(500) NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT47] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T48 | G09 | Effective restrictions, lockups, notice and gates.
CREATE TABLE gold.[dim_liquidity_terms] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [InvestmentContractVersionID] NVARCHAR(500) NOT NULL,
    [SourceRestrictionID] BIGINT NOT NULL,
    [SourceSubscriptionID] BIGINT NULL,
    [EffectiveFrom] DATE NOT NULL,
    [EffectiveToExclusive] DATE NULL,
    [LockupExpiration] DATE NULL,
    [HardLockup] BIT NULL,
    [LockupPenalty] DECIMAL(38,14) NULL,
    [LiquidityFrequency] NVARCHAR(500) NULL,
    [FrequencyDate] DATE NULL,
    [NoticeDays] INT NULL,
    [GateProvision] DECIMAL(38,14) NULL,
    [TermsPolicyID] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT48] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T49 | G09 | As-of per-contract future liquidity buckets.
CREATE TABLE gold.[fact_liquidity_projection] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [InvestmentContractVersionID] NVARCHAR(500) NOT NULL,
    [LiquidityTermsVersionID] NVARCHAR(500) NOT NULL,
    [AsOfDate] DATE NOT NULL,
    [BucketStartDate] DATE NOT NULL,
    [BucketEndExclusive] DATE NOT NULL,
    [ScenarioID] NVARCHAR(500) NOT NULL,
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    [OpeningAvailableNAV] DECIMAL(38,14) NULL,
    [EligibleAmount] DECIMAL(38,14) NULL,
    [GatedAmount] DECIMAL(38,14) NULL,
    [HoldbackAmount] DECIMAL(38,14) NULL,
    [ReserveAmount] DECIMAL(38,14) NULL,
    [PenaltyAmount] DECIMAL(38,14) NULL,
    [AvailabilityStatus] NVARCHAR(500) NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT49] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T50 | G10 | Versioned risk results, observations and benchmark policy.
CREATE TABLE gold.[fact_risk_metric] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [MetricDefinitionID] NVARCHAR(500) NOT NULL,
    [MetricStatus] NVARCHAR(500) NOT NULL,
    [MetricValue] FLOAT NULL,
    [BenchmarkRateID] BIGINT NULL,
    [ObservationFrequency] NVARCHAR(500) NULL,
    [ObservationCount] BIGINT NULL,
    [RequiredObservationCount] BIGINT NULL,
    [StatisticalConvention] NVARCHAR(500) NULL,
    [AnnualizationFactor] FLOAT NULL,
    [ReferenceInputSetID] NVARCHAR(500) NULL,
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    CONSTRAINT [PK_GT50] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T51 | G10 | Cross-sectional return dispersion and weighting.
CREATE TABLE gold.[fact_dispersion] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [MetricDefinitionID] NVARCHAR(500) NOT NULL,
    [MetricStatus] NVARCHAR(500) NOT NULL,
    [PopulationSetID] NVARCHAR(500) NULL,
    [WeightingMethod] NVARCHAR(500) NULL,
    [EligibleMemberCount] BIGINT NULL,
    [ExcludedForInvalidityCount] BIGINT NULL,
    [WeightSum] DECIMAL(38,14) NULL,
    [WeightedReturnSum] FLOAT NULL,
    [WeightedSquaredDeviationSum] FLOAT NULL,
    [DispersionValue] FLOAT NULL,
    CONSTRAINT [PK_GT51] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T52 | G10 | Monetary and percentage return contribution.
CREATE TABLE gold.[fact_performance_contribution] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [MetricDefinitionID] NVARCHAR(500) NOT NULL,
    [MetricStatus] NVARCHAR(500) NOT NULL,
    [ParentNodeID] NVARCHAR(500) NULL,
    [ChildNodeID] NVARCHAR(500) NULL,
    [SecurityID] BIGINT NULL,
    [CurrencyCode] NVARCHAR(500) NOT NULL,
    [MonetaryNumerator] DECIMAL(38,14) NULL,
    [ReturnDenominator] DECIMAL(38,14) NULL,
    [ContributionValue] FLOAT NULL,
    [ContributionUnit] NVARCHAR(500) NULL,
    [LinkingMethodID] NVARCHAR(500) NULL,
    CONSTRAINT [PK_GT52] PRIMARY KEY ([RecordVersionID])
);
GO

-- G-T53 | G10 | Allocation/selection/interaction effects with residual policy.
CREATE TABLE gold.[fact_performance_attribution] (
    [SourceEnvironmentCode] NVARCHAR(500) NOT NULL,
    [SourceOwnerCustomerID] BIGINT NULL,
    [RecordVersionID] NVARCHAR(500) NOT NULL,
    [SourceCaptureSetID] NVARCHAR(500) NOT NULL,
    [InputSetID] NVARCHAR(500) NOT NULL,
    [PipelineRunID] NVARCHAR(500) NOT NULL,
    [RuleVersion] NVARCHAR(500) NOT NULL,
    [CustomerID] BIGINT NOT NULL,
    [LoadDts] DATETIME2(6) NOT NULL,
    [ReportContextKey] BIGINT NOT NULL,
    [ReportTimePeriodID] BIGINT NOT NULL,
    [ReportNodeID] NVARCHAR(500) NOT NULL,
    [CalculationExecutionID] NVARCHAR(500) NOT NULL,
    [PublicationSetID] NVARCHAR(500) NOT NULL,
    [MetricDefinitionID] NVARCHAR(500) NOT NULL,
    [MetricStatus] NVARCHAR(500) NOT NULL,
    [AttributionBucketID] NVARCHAR(500) NULL,
    [EffectCode] NVARCHAR(500) NULL,
    [BenchmarkRateID] BIGINT NULL,
    [PortfolioWeight] FLOAT NULL,
    [BenchmarkWeight] FLOAT NULL,
    [PortfolioReturn] FLOAT NULL,
    [BenchmarkReturn] FLOAT NULL,
    [EffectValue] FLOAT NULL,
    [EffectUnit] NVARCHAR(500) NULL,
    [LinkingMethodID] NVARCHAR(500) NULL,
    [ResidualValue] FLOAT NULL,
    [ContributionInputSetID] NVARCHAR(500) NULL,
    CONSTRAINT [PK_GT53] PRIMARY KEY ([RecordVersionID])
);
GO

-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_customer] ADD CONSTRAINT [AK_GT02] UNIQUE ([SourceEnvironmentCode], [CustomerID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_fund] ADD CONSTRAINT [AK_GT03] UNIQUE ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_security] ADD CONSTRAINT [AK_GT04] UNIQUE ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_portfolio] ADD CONSTRAINT [AK_GT20] UNIQUE ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_investor_profile] ADD CONSTRAINT [AK_GT21] UNIQUE ([SourceEnvironmentCode], [CustomerID], [ProfileID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_chart_of_accounts] ADD CONSTRAINT [AK_GT07] UNIQUE ([SourceEnvironmentCode], [CustomerID], [COAID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_security_class] ADD CONSTRAINT [AK_GT12] UNIQUE ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_security_class_option] ADD CONSTRAINT [AK_GT13] UNIQUE ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_page_grouping] ADD CONSTRAINT [AK_GT22] UNIQUE ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_report_context] ADD CONSTRAINT [AK_GT24] UNIQUE ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_report_time_period] ADD CONSTRAINT [AK_GT25] UNIQUE ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_benchmark] ADD CONSTRAINT [AK_GT14] UNIQUE ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_currency] ADD CONSTRAINT [AK_GT06] UNIQUE ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_date] ADD CONSTRAINT [AK_GT01] UNIQUE ([SourceEnvironmentCode], [DateKey]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_investment_contract] ADD CONSTRAINT [AK_GT45] UNIQUE ([SourceEnvironmentCode], [CustomerID], [InvestmentContractID]);
GO
-- ERD-only business-key target. Not a physically valid uniqueness claim for SCD2 records.
ALTER TABLE gold.[dim_allocation_model] ADD CONSTRAINT [AK_GT43] UNIQUE ([SourceEnvironmentCode], [CustomerID], [AllocationModelID]);
GO
ALTER TABLE gold.[fact_daily_security_performance] ADD CONSTRAINT [AK_GT17_LINEAGE] UNIQUE ([SourceEnvironmentCode], [CustomerID], [SecurityPerformanceID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_fund] ADD CONSTRAINT [FK_ARCH_001] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_security] ADD CONSTRAINT [FK_ARCH_002] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_breakpoint] ADD CONSTRAINT [FK_ARCH_003] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_chart_of_accounts] ADD CONSTRAINT [FK_ARCH_004] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_corporate_action] ADD CONSTRAINT [FK_ARCH_005] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_transaction_type] ADD CONSTRAINT [FK_ARCH_006] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_security_price] ADD CONSTRAINT [FK_ARCH_007] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_security_class] ADD CONSTRAINT [FK_ARCH_008] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_security_class_option] ADD CONSTRAINT [FK_ARCH_009] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_benchmark] ADD CONSTRAINT [FK_ARCH_010] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_nested_profile] ADD CONSTRAINT [FK_ARCH_011] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_security_performance] ADD CONSTRAINT [FK_ARCH_012] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_013] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_014] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_portfolio] ADD CONSTRAINT [FK_ARCH_015] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_investor_profile] ADD CONSTRAINT [FK_ARCH_016] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_page_grouping] ADD CONSTRAINT [FK_ARCH_017] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_report_security_class_pair] ADD CONSTRAINT [FK_ARCH_018] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_context] ADD CONSTRAINT [FK_ARCH_019] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_time_period] ADD CONSTRAINT [FK_ARCH_020] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_security_classification] ADD CONSTRAINT [FK_ARCH_021] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_benchmark_assignment] ADD CONSTRAINT [FK_ARCH_022] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_exchange_rate_daily] ADD CONSTRAINT [FK_ARCH_023] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_returns_base] ADD CONSTRAINT [FK_ARCH_024] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_realized_gains_tax_lot] ADD CONSTRAINT [FK_ARCH_025] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_general_ledger_activity] ADD CONSTRAINT [FK_ARCH_026] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_activity] ADD CONSTRAINT [FK_ARCH_027] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_security_classification] ADD CONSTRAINT [FK_ARCH_028] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_029] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_030] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_031] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_032] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_033] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_034] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_position_valuation_daily] ADD CONSTRAINT [FK_ARCH_035] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_transaction] ADD CONSTRAINT [FK_ARCH_036] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_benchmark_observation] ADD CONSTRAINT [FK_ARCH_037] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_allocation_model] ADD CONSTRAINT [FK_ARCH_038] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_allocation_target] ADD CONSTRAINT [FK_ARCH_039] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_investment_contract] ADD CONSTRAINT [FK_ARCH_040] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_private_capital_event_component] ADD CONSTRAINT [FK_ARCH_041] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_private_capital_position] ADD CONSTRAINT [FK_ARCH_042] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_liquidity_terms] ADD CONSTRAINT [FK_ARCH_043] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_liquidity_projection] ADD CONSTRAINT [FK_ARCH_044] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_risk_metric] ADD CONSTRAINT [FK_ARCH_045] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_dispersion] ADD CONSTRAINT [FK_ARCH_046] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_contribution] ADD CONSTRAINT [FK_ARCH_047] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_attribution] ADD CONSTRAINT [FK_ARCH_048] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID]) REFERENCES gold.[dim_customer] ([SourceEnvironmentCode], [CustomerID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_breakpoint] ADD CONSTRAINT [FK_ARCH_049] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_chart_of_accounts] ADD CONSTRAINT [FK_ARCH_050] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_nested_profile] ADD CONSTRAINT [FK_ARCH_051] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MasterFundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_nested_profile] ADD CONSTRAINT [FK_ARCH_052] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederFundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_security_performance] ADD CONSTRAINT [FK_ARCH_053] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_054] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_055] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederFundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_056] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MasterFundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_057] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederFundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_portfolio] ADD CONSTRAINT [FK_ARCH_058] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_investor_profile] ADD CONSTRAINT [FK_ARCH_059] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederFundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_page_grouping] ADD CONSTRAINT [FK_ARCH_060] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederFundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_context] ADD CONSTRAINT [FK_ARCH_061] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ActiveFundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_time_period] ADD CONSTRAINT [FK_ARCH_062] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_returns_base] ADD CONSTRAINT [FK_ARCH_063] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_realized_gains_tax_lot] ADD CONSTRAINT [FK_ARCH_064] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_general_ledger_activity] ADD CONSTRAINT [FK_ARCH_065] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_activity] ADD CONSTRAINT [FK_ARCH_066] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_067] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_068] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_069] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_070] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_071] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_072] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_position_valuation_daily] ADD CONSTRAINT [FK_ARCH_073] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_transaction] ADD CONSTRAINT [FK_ARCH_074] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_allocation_target] ADD CONSTRAINT [FK_ARCH_075] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_investment_contract] ADD CONSTRAINT [FK_ARCH_076] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FundID]) REFERENCES gold.[dim_fund] ([SourceEnvironmentCode], [CustomerID], [FundID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_corporate_action] ADD CONSTRAINT [FK_ARCH_077] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_security_price] ADD CONSTRAINT [FK_ARCH_078] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_security_performance] ADD CONSTRAINT [FK_ARCH_079] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_080] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_081] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_security_classification] ADD CONSTRAINT [FK_ARCH_082] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_benchmark_assignment] ADD CONSTRAINT [FK_ARCH_083] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_returns_base] ADD CONSTRAINT [FK_ARCH_084] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_realized_gains_tax_lot] ADD CONSTRAINT [FK_ARCH_085] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_general_ledger_activity] ADD CONSTRAINT [FK_ARCH_086] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_activity] ADD CONSTRAINT [FK_ARCH_087] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_security_classification] ADD CONSTRAINT [FK_ARCH_088] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_089] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_090] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_091] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_092] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_093] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_094] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_position_valuation_daily] ADD CONSTRAINT [FK_ARCH_095] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_transaction] ADD CONSTRAINT [FK_ARCH_096] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_investment_contract] ADD CONSTRAINT [FK_ARCH_097] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_contribution] ADD CONSTRAINT [FK_ARCH_098] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityID]) REFERENCES gold.[dim_security] ([SourceEnvironmentCode], [CustomerID], [SecurityID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_security_price] ADD CONSTRAINT [FK_ARCH_099] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FK_PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_nested_profile] ADD CONSTRAINT [FK_ARCH_100] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MasterPortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_nested_profile] ADD CONSTRAINT [FK_ARCH_101] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederPortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_security_performance] ADD CONSTRAINT [FK_ARCH_102] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_103] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_104] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederPortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_105] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MasterPortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_106] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederPortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_investor_profile] ADD CONSTRAINT [FK_ARCH_107] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederPortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_page_grouping] ADD CONSTRAINT [FK_ARCH_108] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [FeederPortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_returns_base] ADD CONSTRAINT [FK_ARCH_109] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_realized_gains_tax_lot] ADD CONSTRAINT [FK_ARCH_110] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_general_ledger_activity] ADD CONSTRAINT [FK_ARCH_111] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_activity] ADD CONSTRAINT [FK_ARCH_112] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_position_valuation_daily] ADD CONSTRAINT [FK_ARCH_113] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_transaction] ADD CONSTRAINT [FK_ARCH_114] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_allocation_target] ADD CONSTRAINT [FK_ARCH_115] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_investment_contract] ADD CONSTRAINT [FK_ARCH_116] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PortfolioID]) REFERENCES gold.[dim_portfolio] ([SourceEnvironmentCode], [CustomerID], [PortfolioID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_nested_profile] ADD CONSTRAINT [FK_ARCH_117] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ProfileID]) REFERENCES gold.[dim_investor_profile] ([SourceEnvironmentCode], [CustomerID], [ProfileID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_118] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ProfileID]) REFERENCES gold.[dim_investor_profile] ([SourceEnvironmentCode], [CustomerID], [ProfileID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_119] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ProfileID]) REFERENCES gold.[dim_investor_profile] ([SourceEnvironmentCode], [CustomerID], [ProfileID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_activity] ADD CONSTRAINT [FK_ARCH_120] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ProfileID]) REFERENCES gold.[dim_investor_profile] ([SourceEnvironmentCode], [CustomerID], [ProfileID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_nested_profile] ADD CONSTRAINT [FK_ARCH_121] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [COAID]) REFERENCES gold.[dim_chart_of_accounts] ([SourceEnvironmentCode], [CustomerID], [COAID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_122] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [COAID]) REFERENCES gold.[dim_chart_of_accounts] ([SourceEnvironmentCode], [CustomerID], [COAID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_123] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [COAID]) REFERENCES gold.[dim_chart_of_accounts] ([SourceEnvironmentCode], [CustomerID], [COAID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_general_ledger_activity] ADD CONSTRAINT [FK_ARCH_124] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [COAID]) REFERENCES gold.[dim_chart_of_accounts] ([SourceEnvironmentCode], [CustomerID], [COAID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_activity] ADD CONSTRAINT [FK_ARCH_125] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [COAID]) REFERENCES gold.[dim_chart_of_accounts] ([SourceEnvironmentCode], [CustomerID], [COAID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_position_valuation_daily] ADD CONSTRAINT [FK_ARCH_126] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [COAID]) REFERENCES gold.[dim_chart_of_accounts] ([SourceEnvironmentCode], [CustomerID], [COAID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_security_class_option] ADD CONSTRAINT [FK_ARCH_127] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_benchmark] ADD CONSTRAINT [FK_ARCH_128] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_report_security_class_pair] ADD CONSTRAINT [FK_ARCH_129] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_report_security_class_pair] ADD CONSTRAINT [FK_ARCH_130] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_context] ADD CONSTRAINT [FK_ARCH_131] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_context] ADD CONSTRAINT [FK_ARCH_132] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_security_classification] ADD CONSTRAINT [FK_ARCH_133] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_security_classification] ADD CONSTRAINT [FK_ARCH_134] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_security_classification] ADD CONSTRAINT [FK_ARCH_135] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_security_classification] ADD CONSTRAINT [FK_ARCH_136] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_137] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_138] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_139] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_140] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_141] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_142] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_143] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_144] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_145] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_146] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_147] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_148] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_allocation_model] ADD CONSTRAINT [FK_ARCH_149] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]) REFERENCES gold.[dim_security_class] ([SourceEnvironmentCode], [CustomerID], [SecurityClassID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_security_classification] ADD CONSTRAINT [FK_ARCH_150] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassOptionID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_security_classification] ADD CONSTRAINT [FK_ARCH_151] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassOptionID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_benchmark_assignment] ADD CONSTRAINT [FK_ARCH_152] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMajorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_benchmark_assignment] ADD CONSTRAINT [FK_ARCH_153] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMinorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_security_classification] ADD CONSTRAINT [FK_ARCH_154] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MajorSecurityClassOptionID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_security_classification] ADD CONSTRAINT [FK_ARCH_155] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [MinorSecurityClassOptionID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_156] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMajorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_157] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMinorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_158] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMajorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_159] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMinorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_160] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMajorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_161] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMinorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_162] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMajorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_163] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMinorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_164] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMajorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_165] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMinorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_166] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMajorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_167] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionMinorID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_allocation_target] ADD CONSTRAINT [FK_ARCH_168] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]) REFERENCES gold.[dim_security_class_option] ([SourceEnvironmentCode], [CustomerID], [SecurityClassOptionID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_context] ADD CONSTRAINT [FK_ARCH_169] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]) REFERENCES gold.[dim_page_grouping] ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_benchmark_assignment] ADD CONSTRAINT [FK_ARCH_170] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]) REFERENCES gold.[dim_page_grouping] ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_171] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]) REFERENCES gold.[dim_page_grouping] ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_172] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]) REFERENCES gold.[dim_page_grouping] ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_173] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]) REFERENCES gold.[dim_page_grouping] ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_174] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]) REFERENCES gold.[dim_page_grouping] ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_175] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]) REFERENCES gold.[dim_page_grouping] ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_176] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]) REFERENCES gold.[dim_page_grouping] ([SourceEnvironmentCode], [CustomerID], [PageGroupingID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_time_period] ADD CONSTRAINT [FK_ARCH_177] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_178] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_179] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_180] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_181] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_182] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_183] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_liquidity_projection] ADD CONSTRAINT [FK_ARCH_184] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_risk_metric] ADD CONSTRAINT [FK_ARCH_185] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_dispersion] ADD CONSTRAINT [FK_ARCH_186] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_contribution] ADD CONSTRAINT [FK_ARCH_187] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_attribution] ADD CONSTRAINT [FK_ARCH_188] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]) REFERENCES gold.[dim_report_context] ([SourceEnvironmentCode], [CustomerID], [ReportContextKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_189] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_190] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_191] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_192] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_193] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_194] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_risk_metric] ADD CONSTRAINT [FK_ARCH_195] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_dispersion] ADD CONSTRAINT [FK_ARCH_196] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_contribution] ADD CONSTRAINT [FK_ARCH_197] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_attribution] ADD CONSTRAINT [FK_ARCH_198] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]) REFERENCES gold.[dim_report_time_period] ([SourceEnvironmentCode], [CustomerID], [ReportTimePeriodID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[bridge_benchmark_assignment] ADD CONSTRAINT [FK_ARCH_199] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]) REFERENCES gold.[dim_benchmark] ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_200] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]) REFERENCES gold.[dim_benchmark] ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_201] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]) REFERENCES gold.[dim_benchmark] ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_202] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]) REFERENCES gold.[dim_benchmark] ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_benchmark_observation] ADD CONSTRAINT [FK_ARCH_203] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]) REFERENCES gold.[dim_benchmark] ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_risk_metric] ADD CONSTRAINT [FK_ARCH_204] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]) REFERENCES gold.[dim_benchmark] ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_attribution] ADD CONSTRAINT [FK_ARCH_205] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]) REFERENCES gold.[dim_benchmark] ([SourceEnvironmentCode], [CustomerID], [BenchmarkRateID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_fund] ADD CONSTRAINT [FK_ARCH_206] FOREIGN KEY ([SourceEnvironmentCode], [FundCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_security_performance] ADD CONSTRAINT [FK_ARCH_207] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_security_performance] ADD CONSTRAINT [FK_ARCH_208] FOREIGN KEY ([SourceEnvironmentCode], [LocalCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_209] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_opening_seed] ADD CONSTRAINT [FK_ARCH_210] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_211] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_212] FOREIGN KEY ([SourceEnvironmentCode], [LocalCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_report_context] ADD CONSTRAINT [FK_ARCH_213] FOREIGN KEY ([SourceEnvironmentCode], [CurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_exchange_rate_daily] ADD CONSTRAINT [FK_ARCH_214] FOREIGN KEY ([SourceEnvironmentCode], [FromCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_exchange_rate_daily] ADD CONSTRAINT [FK_ARCH_215] FOREIGN KEY ([SourceEnvironmentCode], [ToCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_returns_base] ADD CONSTRAINT [FK_ARCH_216] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_realized_gains_tax_lot] ADD CONSTRAINT [FK_ARCH_217] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_realized_gains_tax_lot] ADD CONSTRAINT [FK_ARCH_218] FOREIGN KEY ([SourceEnvironmentCode], [LocalCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_activity] ADD CONSTRAINT [FK_ARCH_219] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_activity] ADD CONSTRAINT [FK_ARCH_220] FOREIGN KEY ([SourceEnvironmentCode], [LocalCurrency]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_inception_dates] ADD CONSTRAINT [FK_ARCH_221] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_period_performance] ADD CONSTRAINT [FK_ARCH_222] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_benchmark_returns_by_period] ADD CONSTRAINT [FK_ARCH_223] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_returns_by_period] ADD CONSTRAINT [FK_ARCH_224] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_market_value_latest] ADD CONSTRAINT [FK_ARCH_225] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_returns_by_period] ADD CONSTRAINT [FK_ARCH_226] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_position_valuation_daily] ADD CONSTRAINT [FK_ARCH_227] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_position_valuation_daily] ADD CONSTRAINT [FK_ARCH_228] FOREIGN KEY ([SourceEnvironmentCode], [LocalCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_transaction] ADD CONSTRAINT [FK_ARCH_229] FOREIGN KEY ([SourceEnvironmentCode], [CurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_benchmark_observation] ADD CONSTRAINT [FK_ARCH_230] FOREIGN KEY ([SourceEnvironmentCode], [CurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[dim_investment_contract] ADD CONSTRAINT [FK_ARCH_231] FOREIGN KEY ([SourceEnvironmentCode], [CurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_private_capital_event_component] ADD CONSTRAINT [FK_ARCH_232] FOREIGN KEY ([SourceEnvironmentCode], [CurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_private_capital_position] ADD CONSTRAINT [FK_ARCH_233] FOREIGN KEY ([SourceEnvironmentCode], [ReportingCurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_liquidity_projection] ADD CONSTRAINT [FK_ARCH_234] FOREIGN KEY ([SourceEnvironmentCode], [CurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_risk_metric] ADD CONSTRAINT [FK_ARCH_235] FOREIGN KEY ([SourceEnvironmentCode], [CurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_performance_contribution] ADD CONSTRAINT [FK_ARCH_236] FOREIGN KEY ([SourceEnvironmentCode], [CurrencyCode]) REFERENCES gold.[dim_currency] ([SourceEnvironmentCode], [CurrencyCode]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_daily_security_performance] ADD CONSTRAINT [FK_ARCH_237] FOREIGN KEY ([SourceEnvironmentCode], [Date]) REFERENCES gold.[dim_date] ([SourceEnvironmentCode], [DateKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_238] FOREIGN KEY ([SourceEnvironmentCode], [Date]) REFERENCES gold.[dim_date] ([SourceEnvironmentCode], [DateKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_realized_gains_tax_lot] ADD CONSTRAINT [FK_ARCH_239] FOREIGN KEY ([SourceEnvironmentCode], [Date]) REFERENCES gold.[dim_date] ([SourceEnvironmentCode], [DateKey]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_private_capital_event_component] ADD CONSTRAINT [FK_ARCH_240] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [InvestmentContractID]) REFERENCES gold.[dim_investment_contract] ([SourceEnvironmentCode], [CustomerID], [InvestmentContractID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[snap_private_capital_position] ADD CONSTRAINT [FK_ARCH_241] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [InvestmentContractID]) REFERENCES gold.[dim_investment_contract] ([SourceEnvironmentCode], [CustomerID], [InvestmentContractID]);
GO
-- PROPOSED_LOGICAL: DESIGN-ONLY: verify business identity; SCD2 joins also require as-of temporal predicate and tenant isolation.
ALTER TABLE gold.[fact_allocation_target] ADD CONSTRAINT [FK_ARCH_242] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [AllocationModelID]) REFERENCES gold.[dim_allocation_model] ([SourceEnvironmentCode], [CustomerID], [AllocationModelID]);
GO
-- SOURCE_LINEAGE_CANDIDATE: Verify whether legacy identifier actually references the corresponding Gold record after migration.
ALTER TABLE gold.[fact_investor_performance_profile] ADD CONSTRAINT [FK_ARCH_243] FOREIGN KEY ([SourceEnvironmentCode], [CustomerID], [SourceDailySecurityPerformanceID]) REFERENCES gold.[fact_daily_security_performance] ([SourceEnvironmentCode], [CustomerID], [SecurityPerformanceID]);
GO