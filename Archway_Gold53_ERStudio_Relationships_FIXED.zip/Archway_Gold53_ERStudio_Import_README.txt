ARCHWAY GOLD 53 ER/STUDIO RELATIONSHIP FIX

Model: 53 Gold tables, 1454 source-design columns, 243 proposed logical FK connectors.

WHY THE PREVIOUS FILE HAD NO RELATIONSHIPS
The Databricks physical metadata and previous SQL defined almost no foreign keys. ER/Studio cannot render business joins from an HTML browser diagram or a separate XMI without a successful relationship import.

IMPORT THIS FILE: Archway_Gold53_ERStudio_Relationships_FIXED.sql
1. ER/Studio Data Architect > File > New > Import Model From > SQL File.
2. Select SQL Server 2019 or newer as the database PLATFORM (not Databricks). This is a modeling-only logical relationship surrogate, not a deployment DDL.
3. Choose the FIXED.sql file; choose Relational model / Tree layout.
4. Import; inspect the import log for FOREIGN KEY entries, not only CREATE TABLE.
5. Check Data Model Explorer Relationships or Foreign Keys and inspect one visible line between dim_customer and fact_daily_security_performance.
6. Save as an ER/Studio .dm1 model; these SQL statements must never be executed against SQL Server or Databricks.

CRITICAL MODEL LIMITS
- No physical FK constraints were verified from Databricks. 243 edges are PROPOSED LOGICAL mappings, not validated PK/FK contracts.
- Business-key UNIQUE constraints in this modeling SQL are scaffolding. On SCD2 tables, CustomerID+business ID is NOT actually unique across versions. Do not forward engineer this script.
- SQL Server normalization uses BIGINT for selected INT/BIGINT ID joins to permit import; see original workbook 04_Column_Mapping for authoritative proposed types.
- Effective date, breakpoint, SourceEnvironmentCode, CustomerID, owner and reporting context validation must be preserved when implementing joins. An ERStudio FK line cannot express the whole temporal predicate.
- Databricks model is maintained independently. These FKs are NOT active production constraints.
- Import logs and diagram layout cannot be tested here: ER/Studio desktop is not available.

SOURCE: Archway_G01_G10_Clean_ETL_and_Reconciliation.xlsx / 02_Pipelines / 03_Objects / 04_Column_Mapping, retained 53 Gold design, 2026-11-07.
